<!-- * Make Paddle
* Make Two Paddles
* Make Paddles Move -->
<!-- * Make Paddles only move to the end -->
<!-- * Make Ball -->
<!-- * Make Ball Move -->


Is the top of the paddle (<=) the bottom end of the ball? AND

Is the bottom of the paddle (>=) the top end of the ball

* Make Collision Physics
* Make Win Check
* Make Scores