Built in Vanilla JS with Canvas, this was the accompaniment to this lecture: https://www.youtube.com/watch?v=_jDHryV20y8
